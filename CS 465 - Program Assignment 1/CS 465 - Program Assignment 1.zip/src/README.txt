IN ORDER TO RUN:
Download Zip file
Extract to desktop
Open command prompt
cd to desktop->unzipped->folder->src
Execute "java DESEncryptor"
Output is written to output.txt